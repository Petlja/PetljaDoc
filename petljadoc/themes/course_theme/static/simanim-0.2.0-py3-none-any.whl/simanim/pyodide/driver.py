import os
import math
from typing import Tuple, Dict, Union
from contextlib import contextmanager, AbstractContextManager
from simanim.abstract.core import DrawingPrimitive, DrawingDriver, AnimSettings
from simanim.abstract.api_primitives import Circle, Box, Line, Image, PolyLine, Arrow, Text
import js

class DrawingDriverJs(DrawingDriver):


    def point_u_to_px(self, point: Tuple[float,float]):
        return self.settings.point_u_to_px(point)

    def scalar_u_to_px(self, scalar: float):
        return self.settings.scalar_u_to_px(scalar)

    def rect_u_to_px(self, xy_min_u: Tuple[float,float], w_u: float, h_u: float) -> Tuple[float,float,float,float]:
        x_min_u, y_min_u = xy_min_u
        x_px, y_px = self.point_u_to_px((x_min_u,y_min_u +h_u))
        w_px = self.scalar_u_to_px(w_u)
        h_px = self.scalar_u_to_px(h_u)
        return x_px, y_px, w_px, h_px

    # Treba prepraviti da umesto paintera ide nešto iz čega će moći da se dohvati canvas na kome se crta
    
    def __init__(self, anim_settings:AnimSettings):
        self.settings = anim_settings
        self.draw_functions_map = {Circle: self.drawCircle, Box: self.drawBox, Line: self.drawLine, 
                                   Image: self.drawImage, PolyLine: self.drawPolyLine, Arrow: self.drawArrow,
                                   Text: self.drawText}


    def draw(self, primitive: DrawingPrimitive):
            self.draw_functions_map[type(primitive)](primitive)


    # sve dalje može ili da preko js modula direktno pristupa browser API-u
    # kao da si u javascriptu ili da poziva JavaScript funkciju u koju se prebaci deo 
    # koda koji pristupa browser API-u (uključujući canvas API)
    def _common_painter_setings(self, primitive:DrawingPrimitive):
        if primitive.pen_color is None:
            primitive.pen_color = '#000000'
        if primitive.line_width is  None:
            primitive.line_width = 0
        primitive.line_width = self.scalar_u_to_px(primitive.line_width)
   
    def drawCircle(self, circle:Circle):
        self._common_painter_setings(circle)
        cx_px, cy_px = self.point_u_to_px(circle.center)
        r_px = self.scalar_u_to_px(circle.radius)
        js.drawCircle(cx_px, cy_px,  r_px, circle.fill_color, circle.line_width, circle.pen_color, circle.line_dashed)

    def drawBox(self, box:Box):
        self._common_painter_setings(box)
        x_px, y_px, w_px, h_px = self.rect_u_to_px(box.xy_min, box.width, box.height)
        js.drawBox( x_px, y_px, w_px, h_px, box.fill_color, box.line_width, box.pen_color, box.line_dashed)

    
    def drawLine(self, line:Line):
        self._common_painter_setings(line)
        x1, y1 = self.point_u_to_px(line.point1)
        x2, y2 = self.point_u_to_px(line.point2)
        js.drawLine( x1, y1, x2, y2, line.fill_color, line.line_width, line.pen_color, line.line_dashed)


    def _drawArrowhead(self, point1:Tuple[float,float], point2:Tuple[float,float], line: Line):
        
        head_r = math.sin(line.head_angle) * line.head_len

        x1, y1 = point1
        x2, y2 = point2
        dx = x2 - x1
        dy = y2 - y1
        distance = math.sqrt(dx**2 + dy**2)

        # normalized direction vector
        ux = (x2 - x1) / distance
        uy = (y2 - y1) / distance

        # perpendicular vector
        px, py = -uy, ux

        cx = x2 - line.head_len * ux
        cy = y2 - line.head_len * uy

        lx = cx + head_r * px
        ly = cy + head_r * py

        rx = cx - head_r * px
        ry = cy - head_r * py
        x2,y2 = self.point_u_to_px((x2,y2))
        rx,ry = self.point_u_to_px((rx,ry))
        lx,ly = self.point_u_to_px((lx,ly))

        js.drawTriangle( x2,y2, rx,ry, lx,ly, line.fill_color, line.line_width, line.pen_color, line.line_dashed)
        return cx, cy


    def drawArrow(self, arrow:Arrow):
        point1, point2 = arrow.point1, arrow.point2
        line = Line(point1, point2)
        line.line_dashed = arrow.line_dashed
        line.line_width = arrow.line_width
        line.pen_color = arrow.pen_color
        line.line_dashed = arrow.line_dashed
        self._common_painter_setings(arrow)
        if arrow.head_len:
             line.point2 = self._drawArrowhead(point1, point2, arrow)
             
        self.drawLine(line)

    def drawPolyLine(self, polyLine:PolyLine):
        self._common_painter_setings(polyLine)
        polyLine.points = [self.point_u_to_px(point) for point in polyLine.points]      
        js.drawPolyLine(polyLine.points, polyLine.fill_color, polyLine.line_width, polyLine.pen_color, polyLine.line_dashed)

    def drawImage(self, image:Image):
        img_key = image.file

        x_px, y_px, w_px, h_px = self.rect_u_to_px(image.xy_min, image.width, image.height)

        js.drawImage(img_key, x_px, y_px, w_px, h_px)

    def drawText(self, text:Text):
        self._common_painter_setings(text)
        x_px, y_px = self.point_u_to_px(text.position)
        fs_px = self.scalar_u_to_px(text.font_size)
        js.drawText(x_px, y_px, fs_px, text.content)

    def Rotate(self, point:Tuple[float,float], angle:float) -> AbstractContextManager:
        @contextmanager
        def rotate_context_manager():
            try:
                js.rotate(self.point_u_to_px(point),angle)
                yield
            finally:
                js.restore()
        return rotate_context_manager()